CREATE OR REPLACE PACKAGE BODY tetools.admin_logger
IS
  -- VER BODY VERSION 20261013_500
  --
  -- /* ================================================================================================================================================================= */
  --  EXCEPTIONS
  -- /* ================================================================================================================================================================= */
  --
  generic_error            EXCEPTION;  PRAGMA EXCEPTION_INIT (generic_error           , -20001);
  failure_in_calling       EXCEPTION;  PRAGMA EXCEPTION_INIT (failure_in_calling      , -20002);
  invalid_parameter        EXCEPTION;  PRAGMA EXCEPTION_INIT (invalid_parameter       , -20003);  -- 'AN INVALID PARAMETER WAS GIVEN. VERIFY ITS USE'
  not_correct_session      EXCEPTION;  PRAGMA EXCEPTION_INIT (not_correct_session     , -20004);  -- 'REQUEST FOR TERMINATION COULD NOT BE PROCESSED. FOLLOW PRECEEDING MESSAGES FOR CAUSE.'
  marked_for_kill          EXCEPTION;  PRAGMA EXCEPTION_INIT (marked_for_kill         , -20005);  -- 'REQUESTED SESSION HAS BEEN MARKED FOR TERMINATION. SYSTEM WILL EJECT SESSION WHEN APPROPRIATE'
  get_help                 EXCEPTION;  PRAGMA EXCEPTION_INIT (get_help                , -20006);
  trm_cfmnd                EXCEPTION;  PRAGMA EXCEPTION_INIT (trm_cfmnd               , -20007);  -- 'TERMINATION REQUEST FOR USER HAS BEEN CONFIRMED.'
  req_denied               EXCEPTION;  PRAGMA EXCEPTION_INIT (req_denied              , -20008);  -- 'REQUEST DENIED: TERMINATION REQUEST <v_trm_id> TARGETS A SYS SESSION OR BACKGROUND PROCESS.'
  need_to_be_admin         EXCEPTION;  PRAGMA EXCEPTION_INIT (need_to_be_admin        , -20009);  -- 'INVOKING USER OF TERMINATION REQUEST NEEDS TO BE AN ADMIN USER FOR THIS REQUEST/SESSION. TERMINATION REQUEST <v_trm_id> AWAITS CONFIRMATION.'
  trm_closed               EXCEPTION;  PRAGMA EXCEPTION_INIT (trm_closed              , -20010);  -- 'TERMINATION REQUEST IS CLOSED, CONFIRMATION IS NOT POSSIBLE.'
  segment_numeral          EXCEPTION;  PRAGMA EXCEPTION_INIT (segment_numeral         , -20011);  --
  version_lt_min           EXCEPTION;  PRAGMA EXCEPTION_INIT (version_lt_min          , -20012);  --
  version_gt_max           EXCEPTION;  PRAGMA EXCEPTION_INIT (version_gt_max          , -20013);  --
  version_validation       EXCEPTION;  PRAGMA EXCEPTION_INIT (version_validation      , -20014);  --
  too_many_sessions        EXCEPTION;  PRAGMA EXCEPTION_INIT (too_many_sessions       , -20015);  --
  invalid_numsessions      EXCEPTION;  PRAGMA EXCEPTION_INIT (invalid_numsessions     , -20016);  --
  corrupt_logger_target    EXCEPTION;  PRAGMA EXCEPTION_INIT (corrupt_logger_target   , -20017);  --
  not_correct_phase        EXCEPTION;  PRAGMA EXCEPTION_INIT (not_correct_phase       , -20018);  -- 'THE PHASE GIVEN IS NOT COMMONLY USED IN GD.'
  no_valid_domain          EXCEPTION;  PRAGMA EXCEPTION_INIT (no_valid_domain         , -20019);  -- 'DOMAIN NAME VALIDATION FAILED, MOST LIKELY A DOMAIN NOT COMMONLY USED IN GD.'
  hostname_validation      EXCEPTION;  PRAGMA EXCEPTION_INIT (hostname_validation     , -20020);  -- 'VALIDATION OF THE HOSTNAME FAILED, MOST LIKELY A TYPO.'
  fqdn_validation          EXCEPTION;  PRAGMA EXCEPTION_INIT (fqdn_validation         , -20021);  -- 'VALIDATION OF THE FQDN FAILED FOR THE GIVEN HOSTNAME, CHECK AGAIN.'
  ip_invalid               EXCEPTION;  PRAGMA EXCEPTION_INIT (ip_invalid              , -20022);  -- 'VALIDATION OF THE GIVEN IP ADDRESS FAILED, EITHER FORMAT IS WRONG OR A BROADCAST ADDRESS WAS GIVEN.'
  shortname_validation     EXCEPTION;  PRAGMA EXCEPTION_INIT (shortname_validation    , -20023);  -- 'VALIDATION OF THE DB SERVER SHORTNAME FAILED, MOST LIKELY A SUBDOMAIN.'
  ip_format_invalid        EXCEPTION;  PRAGMA EXCEPTION_INIT (ip_format_invalid       , -20024);  -- 'IP ADDRESS FORMAT IS INVALID'
  port_validation          EXCEPTION;  PRAGMA EXCEPTION_INIT (port_validation         , -20025);  -- 'PORT VALIDATION FAILED'
  no_contributor           EXCEPTION;  PRAGMA EXCEPTION_INIT (no_contributor          , -20026);  -- 'INVOKING USER HAS NO PRIVILEGES TO CONTRIBUTE TO TNSNAMES. CONTACT TET.'
  maintenance_mode_enabled EXCEPTION;  PRAGMA EXCEPTION_INIT (maintenance_mode_enabled, -20027);  -- 'INVOKING USER HAS NO PRIVILEGES TO ADMINISTER TO TNSNAMES WHILE MAINTENANCE MODE IS ENABLED. CONTACT TET.'
  no_update_found          EXCEPTION;  PRAGMA EXCEPTION_INIT (no_update_found         , -20028);  -- 'NO DISCERNABLE UPDATE VALUES FOUND TO PROCESS AS TNS REGISTRATION. TRY AGAIN.'
  operation_halted         EXCEPTION;  PRAGMA EXCEPTION_INIT (operation_halted        , -20029);  -- 'SOMEHOW, SOMEWHERE, SOMETHINGs NOT GOOD. TRY AGAIN. CALL TET.'
  wrong_crud               EXCEPTION;  PRAGMA EXCEPTION_INIT (wrong_crud              , -20030);  -- 'CANt UPDATE WHEN IT ALREADY EXISTS, OR SIMILAR. TRY AGAIN.'
  mismatch_type_numhosts   EXCEPTION;  PRAGMA EXCEPTION_INIT (mismatch_type_numhosts  , -20031);  -- 'A SPECIFIC NUMBER OF ADDRESSES CAN/MUST BE USED WITH THE TYPE OF REGISTRATION. SIMPLE: 1, ADVANCED: 1 to 3.'
  invalid_numhosts         EXCEPTION;  PRAGMA EXCEPTION_INIT (invalid_numhosts        , -20032);  -- 'A SPECIFIC RANGE OF NUMBER OF ADDRESSES CAN BE USED TO REGISTER A NET SERVICE NAME: [1 - 3].'
  validation_error         EXCEPTION;  PRAGMA EXCEPTION_INIT (validation_error        , -20033);  -- 'A VALIDATION ERROR HAS OCCURED VALIDATING THE PROTO TNS ENTRY. SEE FEEDBACK FOR OFFENDING ATTRIBUTE.'
  no_parent_attr_name      EXCEPTION;  PRAGMA EXCEPTION_INIT (no_parent_attr_name     , -20034);  -- 'A PARSE ERROR HAS OCCURED TRYING TO VALIDATE THE GIVEN ATTRIBUTE NAME. THIS ATTRIBUTE HAS BEEN MISSPELLED OR NOT IN SUPPORT.'
  crud_retrieve            EXCEPTION;  PRAGMA EXCEPTION_INIT (crud_retrieve           , -20035);
  crud_read                EXCEPTION;  PRAGMA EXCEPTION_INIT (crud_read               , -20036);  -- 'REQUESTED CRUD OPERATION (READ) NOT APPLICABLE FOR THIS PACKAGE.'
  crud_unknown             EXCEPTION;  PRAGMA EXCEPTION_INIT (crud_unknown            , -20037);
  idx_internal_check       EXCEPTION;  PRAGMA EXCEPTION_INIT (idx_internal_check      , -20038);
  already_cataloged        EXCEPTION;  PRAGMA EXCEPTION_INIT (already_cataloged       , -20039);
  missing_logsession       EXCEPTION;  PRAGMA EXCEPTION_INIT (missing_logsession      , -20040);
  --
  -- /* ================================================================================================================================================================= */
  --  TYPES
  -- /* ================================================================================================================================================================= */
  --
  TYPE session_rt    IS RECORD ( logsession_id     ADMIN_LOGGER_SESSIONS.LOGSESSION_ID%TYPE,
                                 sid               ADMIN_LOGGER_SESSIONS.SID%TYPE,
                                 serial#           ADMIN_LOGGER_SESSIONS.SERIAL#%TYPE,
                                 audsid            ADMIN_LOGGER_SESSIONS.AUDSID%TYPE,
                                 logon_user        ADMIN_LOGGER_SESSIONS.LOGON_USER%TYPE,
                                 logon_time        ADMIN_LOGGER_SESSIONS.LOGON_TIME%TYPE,
                                 current_user      ADMIN_LOGGER_SESSIONS.CURRENT_USER%TYPE,
                                 current_schema    ADMIN_LOGGER_SESSIONS.CURRENT_SCHEMA%TYPE,
                                 proxy_user        ADMIN_LOGGER_SESSIONS.PROXY_USER%TYPE
                               );
  --
  TYPE config_rt     IS RECORD ( config_id         ADMIN_LOGGER_CONFIG.CONFIG_ID%TYPE,
                                 logging_on        BOOLEAN                                  DEFAULT FALSE,
                                 logging_target    ADMIN_LOGGER_CONFIG.LOGGER_TARGET%TYPE   DEFAULT c_to_table,
                                 debug_on          BOOLEAN                                  DEFAULT g_debug_on,
                                 debug_target      ADMIN_LOGGER_CONFIG.DEBUG_TARGET%TYPE    DEFAULT g_override_target,
                                 batch_mode        ADMIN_LOGGER_CONFIG.BATCH_MODE%TYPE      DEFAULT c_b
                               ); 
  --
  TYPE config_bck_rt IS RECORD ( config_key        CHAR(5),
                                 config_id         ADMIN_LOGGER_CONFIG.CONFIG_ID%TYPE,
                                 logging_on        BOOLEAN,
                                 logging_target    ADMIN_LOGGER_CONFIG.LOGGER_TARGET%TYPE,
                                 debug_on          BOOLEAN,
                                 debug_target      ADMIN_LOGGER_CONFIG.DEBUG_TARGET%TYPE,
                                 batch_mode        ADMIN_LOGGER_CONFIG.BATCH_MODE%TYPE,
                                 log_batch         PLS_INTEGER
                               ); 
  --
  TYPE logging_rt   IS RECORD  ( log_batch         ADMIN_LOGGER_LOG.LOGBATCH_ID%TYPE,
                                 log_lines         ADMIN_LOGGER_LOG.LOG_LINES%TYPE
					    	   );
  --
  TYPE incident_rt  IS RECORD  ( incident_id       ADMIN_LOGGER_INCIDENT.INCIDENT_ID%TYPE,
                                 context           ADMIN_LOGGER_INCIDENT.CONTEXT%TYPE,
								 status            ADMIN_LOGGER_INCIDENT.STATUS%TYPE,
								 sid               ADMIN_LOGGER_INCIDENT.SID%TYPE,
								 serial#           ADMIN_LOGGER_INCIDENT.SERIAL#%TYPE,
                                 audsid            ADMIN_LOGGER_INCIDENT.AUDSID%TYPE,
								 logon_user        ADMIN_LOGGER_INCIDENT.LOGON_USER%TYPE,
								 logon_time        ADMIN_LOGGER_INCIDENT.LOGON_TIME%TYPE,
                                 current_user      ADMIN_LOGGER_INCIDENT.CURRENT_USER%TYPE,
                                 current_schema    ADMIN_LOGGER_INCIDENT.CURRENT_SCHEMA%TYPE,
                                 proxy_user        ADMIN_LOGGER_INCIDENT.PROXY_USER%TYPE,
								 new_logsession_id ADMIN_LOGGER_INCIDENT.NEW_LOGSESSION_ID%TYPE,
								 callstack         ADMIN_LOGGER_INCIDENT.CALLSTACK%TYPE,
								 backtrace         ADMIN_LOGGER_INCIDENT.BACKTRACE%TYPE
					    	   );
  --
  g_session_rt          session_rt;
  g_config_rt           config_rt;
  g_config_bck_rt       config_bck_rt;
  g_logging_rt          logging_rt;
  g_incident_rt         incident_rt;
  --
  --
  -- /* ================================================================================================================================================================= */
  --  FUNCTIONS
  -- /* ================================================================================================================================================================= */
  --
  -- /* FUNCTION > gen_token --------------------------------------------------------------- VARCHAR2 ----- */
  -- 
  FUNCTION gen_token RETURN VARCHAR2 
  IS
    v_return CHAR(5);
  BEGIN
  --
    RETURN dbms_random.string('x',5);
  --
  END gen_token;
  --
  -- /* FUNCTION > bool2vc --------------------------------------------------------------------- BOOL ----- */
  -- 
  FUNCTION bool2vc (bool IN BOOLEAN) RETURN VARCHAR2 
  IS 
  BEGIN
	--
     RETURN CASE 
               WHEN bool     THEN 'TRUE' 
               WHEN NOT bool THEN 'FALSE' 
               ELSE               'NULL' 
            END; 
  END bool2vc;
  --
  -- /* FUNCTION > bool2c ---------------------------------------------------------------------- BOOL ----- */
  -- 
  FUNCTION bool2c (bool IN BOOLEAN) RETURN CHAR 
  IS 
  BEGIN
	--
     RETURN CASE 
               WHEN bool     THEN 'Y' 
               WHEN NOT bool THEN 'N' 
               ELSE               'NULL' 
            END; 
  END bool2c;
  -- 
  -- /* FUNCTION > char2bool ------------------------------------------------------------------- CHAR ----- */
  -- 
  FUNCTION char2bool (string IN CHAR) RETURN BOOLEAN 
  IS 
  BEGIN
	--
     RETURN CASE 
               WHEN string = 'Y'     THEN TRUE
               WHEN string = 'N'     THEN FALSE
               ELSE                       FALSE
            END; 
  END char2bool;
  --
  -- /* FUNCTION > get_invoking_sid ---------------------------------------------------- INVOKING_SID ----- */
  --
  FUNCTION get_invoking_sid RETURN NUMBER
  AS
   v_return NUMBER;
  BEGIN
	--
    SELECT SYS_CONTEXT('userenv','sid') INTO v_return FROM dual;
  --
    RETURN v_return;
  END get_invoking_sid;
  --
  -- /* FUNCTION > get_invoking_serial --------------------------------------------- INVOKING_SERIAL# ----- */
  --
  FUNCTION get_invoking_serial RETURN NUMBER
  AS
   v_return NUMBER;
  BEGIN
	--
    SELECT dbms_debug_jdwp.current_session_serial INTO v_return FROM dual;
  --
    RETURN v_return;
  END get_invoking_serial;
  --
  -- /* FUNCTION > get_audsid ---------------------------------------------------- TARGET SID/SERIAL# ----- */
  --
  FUNCTION get_audsid ( p_sid IN NUMBER, p_serial IN NUMBER ) RETURN NUMBER
  AS
    v_return NUMBER;
  BEGIN
	--
      SELECT audsid INTO v_return
      FROM v$session
     WHERE sid = p_sid
       AND serial# = p_serial;
  --
    RETURN v_return;
  END get_audsid;
  --
  -- /* FUNCTION > get_logon_time ---------------------------------------------------- LOGON_TIME ----- */
  --
  FUNCTION get_logon_time ( p_sid IN NUMBER, p_serial IN NUMBER ) RETURN DATE
  AS
   v_return DATE;
  BEGIN
	--
    SELECT logon_time INTO v_return FROM V$SESSION ses WHERE sid = p_sid AND serial# = p_serial;
    RETURN v_return;
  END get_logon_time;
  --
  -- /* FUNCTION > logging_is_on ------------------------------------------ ADMIN_LOGGER_SETTINGS ----- */
  --
  FUNCTION logging_is_on         ( p_settings_id IN INTEGER DEFAULT NULL
                                  ) RETURN CHAR
  IS 
    l_log_settings     admin_logger_config%ROWTYPE;
    l_session_dets     admin_logger_sessions%ROWTYPE;
    l_log              CHAR (1); 
    l_filter           VARCHAR2 (100);
    l_return           CHAR(1) DEFAULT 'N';
  BEGIN
	--
	session_details;
    --
    l_return := admin_logger.bool2c(g_config_rt.logging_on);
	RETURN l_return;
  END logging_is_on;
  --
  -- /* FUNCTION > debug_is_on -------------------------------------------- ADMIN_LOGGER_SETTINGS ----- */
  --
  FUNCTION debug_is_on            ( p_settings_id IN INTEGER DEFAULT NULL
                                  ) RETURN CHAR
  IS 
    l_log_settings     admin_logger_config%ROWTYPE;
    l_session_dets     admin_logger_sessions%ROWTYPE;
    l_log              CHAR (1); 
    l_filter           VARCHAR2 (100);
    l_return           CHAR(1) DEFAULT 'N';
  BEGIN
	--
	session_details;
    --
    l_return := admin_logger.bool2c(g_config_rt.debug_on);
	RETURN l_return;
  END debug_is_on;
  --
  -- /* FUNCTION > get_batchid -------------------------------------------------------------- INTEGER ----- */
  -- 
  FUNCTION get_batchid ( batch_mode IN CHAR ) RETURN INTEGER 
  IS
    v_return PLS_INTEGER;
  BEGIN
  --
    toggle_batch (modus => c_on, batch => batch_mode);
	RETURN g_logging_rt.log_batch;
  --
  END get_batchid;
  --
  --
  -- /* ================================================================================================================================================================= */
  --  PROCEDURES
  -- /* ================================================================================================================================================================= */
  --
  --
  --
  -- /* PROCEDURE > help --------------------------------------------------------------------------------------- USAGE EXAMPLES ----- */
  --
  PROCEDURE help( verbose IN VARCHAR2 DEFAULT 'N')
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    v_rowtext                VARCHAR2(32767);
    v_filter_y               VARCHAR2(40) := '^[[:space:]]{2}[\-]{2}[H][SV][\-]';
    v_filter_n               VARCHAR2(40) := '^[[:space:]]{2}[\-]{2}[H][S][\-]';
    v_filter_help            VARCHAR2(64) := v_filter_y || '[[:space:]]';
    v_verbose                VARCHAR2(64) := v_filter_n;
	v_token                  VARCHAR2(5)  := admin_logger.gen_token;
    v_result                 CLOB;
	v_full_clob              CLOB;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  	CURSOR c_help(p_object IN VARCHAR2, p_verbose IN VARCHAR2) IS
  	  SELECT line, text
  	    FROM dba_source
  	   WHERE name=p_object
  	     AND type ='PACKAGE'
  	     AND owner='TETOOLS'
  	     AND REGEXP_LIKE(text, p_verbose)
  	     ORDER BY 1 ASC;
  BEGIN
	--
    session_details;
	session_details_revert('BACKUP', v_token);
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => l_context||'.help', action_name => 'Display HELP section for package '||l_context||'.');
	--
	IF    UPPER(verbose) = c_y   THEN
	  v_verbose := v_filter_y;
	ELSIF ( SUBSTR( UPPER(verbose), 1, 4 ) = c_helpme ) AND ( LENGTH( verbose ) = 8 ) THEN
	  v_verbose := v_filter_help || SUBSTR(UPPER(verbose), -3, 3);
	END IF;
	--
	DBMS_LOB.CREATETEMPORARY(v_full_clob,TRUE);
	DBMS_LOB.OPEN(v_full_clob, DBMS_LOB.LOB_READWRITE);
	DBMS_LOB.append(v_full_clob, v_caller||':: '||CHR(10));
	--
  	FOR r_row IN c_help(l_context, v_verbose)
    LOOP
	  DBMS_LOB.append(v_full_clob, REPLACE(r_row.text,',',', '));
    END LOOP;
	--
	toggle_debug(modus => c_on, set_debug_target => c_to_screen);
	tetools.admin_logger.log_runtime (l_context, v_full_clob);
	--
	session_details_revert('RESTORE', v_token);
	--
	DBMS_LOB.CLOSE(lob_loc => v_full_clob);
    DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
	--
	DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
    EXCEPTION
      WHEN failure_in_calling                                                                                                THEN
	    session_details_revert('RESTORE', v_token);
	    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
        v_result := DBMS_UTILITY.format_error_stack;
		log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
	    --
	    DBMS_LOB.CLOSE(lob_loc => v_full_clob);
        DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
  	  WHEN get_help                                                                                                            THEN
  	    help('HELP SHC');
      WHEN OTHERS                                                                                                              THEN
	    session_details_revert('RESTORE', v_token);
	    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
        v_result := DBMS_UTILITY.format_error_stack;
		log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
	    --
	    DBMS_LOB.CLOSE(lob_loc => v_full_clob);
        DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
        RAISE;
	--
  END help;
  --
  -- /* PROCEDURE > banner -------------------------------------------------------------------------- PACKAGE DETAILS / HISTORY ----- */
  --
  PROCEDURE banner
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    v_rowtext                VARCHAR2(32767);
	v_full_clob              CLOB;
	v_result                 CLOB;
	v_token                  VARCHAR2(5)  := admin_logger.gen_token;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  	CURSOR c_banner(p_object IN VARCHAR2) IS
  	  SELECT line, text
  	    FROM dba_source
  	   WHERE name=p_object
  	     AND type ='PACKAGE'
  	     AND owner='TETOOLS'
  	     AND REGEXP_LIKE(text, '^[[:space:]]{2}[\-]{2}[B][\-]')
  	     ORDER BY 1 ASC;
  BEGIN
	--
	session_details;
	session_details_revert('BACKUP', v_token);
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => l_context||'.banner', action_name => 'Display the BANNER for package '||l_context||'.');
    --
	DBMS_LOB.CREATETEMPORARY(v_full_clob,TRUE);
	DBMS_LOB.OPEN(v_full_clob, DBMS_LOB.LOB_READWRITE);
	DBMS_LOB.append(v_full_clob, v_caller||':: '||CHR(10));
	--
  	FOR r_row IN c_banner(l_context)
    LOOP
	  DBMS_LOB.append(v_full_clob, REPLACE(r_row.text,',',', '));
    END LOOP;
	--
	toggle_debug(modus => c_on, set_debug_target => c_to_screen);
	tetools.admin_logger.log_runtime (l_context, v_full_clob);
	--
	DBMS_LOB.CLOSE(lob_loc => v_full_clob);
    DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
	--
	session_details_revert('RESTORE', v_token);
	--
	DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
    EXCEPTION
      WHEN failure_in_calling                                                                                                THEN
	    session_details_revert('RESTORE', v_token);
	    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
        v_result := DBMS_UTILITY.format_error_stack;
		log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
	    --
	    DBMS_LOB.CLOSE(lob_loc => v_full_clob);
        DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
  	  WHEN get_help                                                                                                            THEN
  	    help('HELP SHC');
      WHEN OTHERS                                                                                                              THEN
	    session_details_revert('RESTORE', v_token);
	    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
        v_result := DBMS_UTILITY.format_error_stack;
		log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
	    --
	    DBMS_LOB.CLOSE(lob_loc => v_full_clob);
        DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
        RAISE;
  END banner;
  --
  -- /* PROCEDURE > version ------------------------------------------------------------------------- PACKAGE DETAILS / HISTORY ----- */
  --
  PROCEDURE version
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    v_rowtext                VARCHAR2(32767);
	v_full_clob              CLOB;
	v_result                 CLOB;
	v_token                  VARCHAR2(5)  := admin_logger.gen_token;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  	CURSOR c_versions(p_object IN VARCHAR2) IS
  	  SELECT line, text
  	    FROM dba_source
  	   WHERE name  = p_object
  	     AND type IN ('PACKAGE', 'PACKAGE BODY')
  	     AND owner = 'TETOOLS'
  	     AND REGEXP_LIKE(text, '^[[:space:]]{2}[\-]{2}[[:space:]]VER')
  	     ORDER BY 1 ASC;
  BEGIN
	--
	session_details;
	session_details_revert('BACKUP', v_token);
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => l_context||'.banner', action_name => 'Display version numbers for package '||l_context||'.');
    --
	DBMS_LOB.CREATETEMPORARY(v_full_clob,TRUE);
	DBMS_LOB.OPEN(v_full_clob, DBMS_LOB.LOB_READWRITE);
	DBMS_LOB.append(v_full_clob, v_caller||':: '||CHR(10));
	--
  	FOR r_row IN c_versions(l_context)
    LOOP
	  DBMS_LOB.append(v_full_clob, REPLACE(r_row.text,'-- VER',' '));
    END LOOP;
	--
	toggle_debug(modus => c_on, set_debug_target => c_to_screen);
	tetools.admin_logger.log_runtime (l_context, v_full_clob);
	--
	DBMS_LOB.CLOSE(lob_loc => v_full_clob);
    DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
	--
	session_details_revert('RESTORE', v_token);
	--
	DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
    EXCEPTION
      WHEN failure_in_calling                                                                                                THEN
	    session_details_revert('RESTORE', v_token);
	    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
        v_result := DBMS_UTILITY.format_error_stack;
		log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
	    --
	    DBMS_LOB.CLOSE(lob_loc => v_full_clob);
        DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
  	  WHEN get_help                                                                                                            THEN
  	    help('HELP SHC');
      WHEN OTHERS                                                                                                              THEN
	    session_details_revert('RESTORE', v_token);
	    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
        v_result := DBMS_UTILITY.format_error_stack;
		log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
	    --
	    DBMS_LOB.CLOSE(lob_loc => v_full_clob);
        DBMS_LOB.FREETEMPORARY(lob_loc => v_full_clob);
        RAISE;
  END version;
  --
  -- /* PROCEDURE > save_logger_config -------------------------------------------------------------------------------- ROWTYPE ----- */
  --
  PROCEDURE save_logger_config
  AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
	v_result                 CLOB;
    l_count                  PLS_INTEGER;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
    l_logger_config          admin_logger_config%ROWTYPE;
	v_upd_logger             VARCHAR2(4000) := 'UPDATE TETOOLS.ADMIN_LOGGER_CONFIG SET logger_on = :1, logger_target = :2, debug_on = :3, debug_target = :4, batch_mode = :5, logbatch_id = :6 WHERE logsession_id = :7';
  BEGIN
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.update_logger_config', action_name => 'Logging procedure for logger config.');
	--
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
	DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
	--
	/* Make sure there is a row */ 
	SELECT COUNT(*) INTO l_count
	  FROM admin_logger_config
     WHERE             1 = 1
       AND logsession_id = g_session_rt.logsession_id;
    --
    IF l_count = 1       THEN 
	  --
	  EXECUTE IMMEDIATE v_upd_logger USING IN BOOL2C(g_config_rt.logging_on), g_config_rt.logging_target, BOOL2C(g_config_rt.debug_on), g_config_rt.debug_target, g_config_rt.batch_mode, g_logging_rt.log_batch, g_session_rt.logsession_id;
      COMMIT;
	ELSE
	  RAISE invalid_numsessions;
	END IF;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
  EXCEPTION 
    WHEN generic_error                          THEN
	  DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
	  DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': generic_error '||CHR(10)||v_result );
      NULL; 
    WHEN invalid_numsessions                    THEN
	  DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
	  DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': invalid_numsessions '||CHR(10)||v_result );
      NULL;
	WHEN OTHERS                                 THEN
	  DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
	  DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
      RAISE;
	--
  END save_logger_config;
  --
  -- /* PROCEDURE > session_detail_incident ------------------------------------------------------------------------- V$SESSION ----- */
  --
  PROCEDURE session_detail_incident ( issue IN VARCHAR2, inc_id IN INTEGER DEFAULT NULL )
  AS
    PRAGMA                   AUTONOMOUS_TRANSACTION; 
    l_context                VARCHAR2(128)  := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    l_logger_config          admin_logger_config%ROWTYPE;
    l_logger_sessions        admin_logger_sessions%ROWTYPE;
	l_incident_saved         BOOLEAN        := FALSE;
	l_null                   CHAR(1);
	v_incident_status        VARCHAR2(12)   := 'SUBMITTED';
	v_incident_id            PLS_INTEGER;
	v_logsession_id          PLS_INTEGER;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_count                  PLS_INTEGER;
    v_sid                    PLS_INTEGER;
    v_serial                 PLS_INTEGER;
    v_audsid                 PLS_INTEGER;
	v_logon_user             VARCHAR2(128);
	v_current_user           VARCHAR2(128);
	v_current_schema         VARCHAR2(128);
	v_proxy_user             VARCHAR2(128);
	v_logontime              DATE;
    v_callstack              CLOB           := DBMS_UTILITY.format_call_stack ;
	v_backtrace              CLOB           := DBMS_UTILITY.format_error_backtrace;
	v_errorstack             CLOB           := DBMS_UTILITY.format_error_stack;
	v_ins_incident           VARCHAR2(4000) := 'INSERT INTO TETOOLS.ADMIN_LOGGER_INCIDENT (created_on, context, status, reason, sid, serial#, audsid, logon_user, logon_time, current_user, current_schema, proxy_user, callstack, backtrace) VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14)';
	v_upd_incident           VARCHAR2(4000) := 'UPDATE TETOOLS.ADMIN_LOGGER_INCIDENT SET status = :1 WHERE incident_id = :2';
	v_sql_sessions           VARCHAR2(4000) := 'INSERT INTO TETOOLS.ADMIN_LOGGER_SESSIONS (created_on, sid, serial#, audsid, logon_user, logon_time, current_user, current_schema, proxy_user, incident_id) VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10)';
	v_sql_config             VARCHAR2(4000) := 'INSERT INTO TETOOLS.ADMIN_LOGGER_CONFIG (created_on, logsession_id, logger_on, logger_target, debug_on, debug_target, batch_mode, logbatch_id) VALUES (:1, :2, :3, :4, :5, :6, :7, :8)';
	v_del_sessions           VARCHAR2(4000) := 'DELETE FROM TETOOLS.ADMIN_LOGGER_SESSIONS WHERE logsession_id = :1';
	v_del_config             VARCHAR2(4000) := 'DELETE FROM TETOOLS.ADMIN_LOGGER_CONFIG WHERE logsession_id = :1';
	--
  BEGIN
    --
    /* VALIDATE INPUT PARAMETERS */
	IF    issue IS NULL OR issue NOT IN ( 'missing_id', 'extra_id')                 THEN
	  RAISE failure_in_calling;
	END IF;
	IF    issue = c_helpme                                                          THEN
	  RAISE get_help;
	END IF;
	--
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
	g_session_rt.logsession_id     := NULL;
	g_config_rt.config_id          := NULL;
	g_config_rt.logging_on         := NULL;
    g_config_rt.logging_target     := NULL;
    g_config_rt.debug_on           := NULL;
    g_config_rt.debug_target       := NULL;
	g_config_rt.batch_mode         := NULL;
    g_logging_rt.log_batch         := NULL;
	--
  	SELECT tetools.admin_logger.get_invoking_sid                     INTO v_sid            FROM DUAL;
	SELECT tetools.admin_logger.get_invoking_serial                  INTO v_serial         FROM DUAL;
	SELECT tetools.admin_logger.get_audsid(v_sid, v_serial)          INTO v_audsid         FROM DUAL;
	SELECT tetools.admin_logger.get_logon_time(v_sid, v_serial)      INTO v_logontime      FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'SESSION_USER')                    INTO v_logon_user     FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'CURRENT_USER')                    INTO v_current_user   FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')                  INTO v_current_schema FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'PROXY_USER')                      INTO v_proxy_user     FROM DUAL;
	--
	IF inc_id IS NULL                                                               THEN
	  EXECUTE IMMEDIATE v_ins_incident || ' RETURNING INCIDENT_ID INTO :NEW_INCIDENT' USING IN SYSTIMESTAMP, l_context, 'SUBMITTED', issue, v_sid, v_serial, v_audsid, v_logon_user, v_logontime, v_current_user, v_current_schema, v_proxy_user, v_callstack, v_backtrace, OUT v_incident_id;
	ELSE
	  v_incident_id := inc_id;
      SELECT COUNT(*) INTO l_count FROM tetools.admin_logger_incident
       WHERE incident_id  = v_incident_id
	     AND         sid  = v_sid 
		 AND     serial#  = v_serial
         AND      audsid  = v_audsid
		 AND  logon_user  = v_logon_user
		 AND  logon_time  = v_logontime
         AND      status IN ('SUBMITTED','OPEN');
		 EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
	  --
      IF l_count != 1 THEN RAISE failure_in_calling; END IF;
	  --
	  v_incident_status := 'OPEN';
	  EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
	  --
	  IF SQL%ROWCOUNT != 1 THEN RAISE failure_in_calling; END IF;
	END IF;
	--
	COMMIT;
    --
	SELECT COUNT(*) INTO l_count
	  FROM admin_logger_sessions
     WHERE          1 = 1
       AND sid        = v_sid
       AND serial#    = v_serial
       AND logon_user = v_logon_user
       AND audsid     = v_audsid
       AND logon_time = v_logontime;
	--
	IF l_count = 1 THEN
      --	
	  SELECT * INTO l_logger_sessions
	    FROM tetools.admin_logger_sessions
	   WHERE          1 = 1
         AND sid        = v_sid
         AND serial#    = v_serial
         AND logon_user = v_logon_user
         AND audsid     = v_audsid
         AND logon_time = v_logontime;
	  --
	  SELECT * INTO l_logger_config
	    FROM tetools.ADMIN_LOGGER_CONFIG
	   WHERE logsession_id  = l_logger_sessions.logsession_id;
	  --
	  g_session_rt.logsession_id     := l_logger_sessions.logsession_id;
	  g_config_rt.config_id          := l_logger_config.config_id;
	  g_config_rt.logging_on         := char2bool(l_logger_config.logger_on);
      g_config_rt.logging_target     := l_logger_config.logger_target;
      g_config_rt.debug_on           := char2bool(l_logger_config.debug_on);
      g_config_rt.debug_target       := l_logger_config.debug_target;
	  g_config_rt.batch_mode         := l_logger_config.batch_mode;
      g_logging_rt.log_batch         := l_logger_config.logbatch_id;
      --
	  v_incident_status := 'CLOSED';
      EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
	  COMMIT;
      --
      RETURN;
	END IF;
	--
	IF    issue = 'missing_id'                                                      THEN
	  IF inc_id IS NULL THEN
		v_incident_status := 'OPEN';
	    EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
	  END IF;
	  --
	  IF    l_count > 1 THEN
		session_detail_incident( issue => 'extra_id', inc_id => v_incident_id );
	  END IF;
	  --
	ELSIF issue = 'extra_id'                                                        THEN
	  FOR r_row IN (
	    SELECT logsession_id
		  FROM tetools.admin_logger_sessions
		 WHERE        sid = v_sid
		   AND    serial# = v_serial
		   AND logon_user = v_logon_user
		   AND     audsid = v_audsid
		   AND logon_time = v_logontime
		 ORDER BY logsession_id ) LOOP
	    EXECUTE IMMEDIATE v_del_config USING IN r_row.logsession_id;
        EXECUTE IMMEDIATE v_del_sessions USING IN r_row.logsession_id;
      END LOOP;
	END IF;
	--
	v_incident_status := 'RESOLVED';
	EXECUTE IMMEDIATE v_sql_sessions || ' RETURNING LOGSESSION_ID INTO :NEW_SESSION' USING IN SYSTIMESTAMP, v_sid, v_serial, v_audsid, v_logon_user, v_logontime, v_current_user, v_current_schema, l_null, v_incident_id, OUT v_logsession_id;
	EXECUTE IMMEDIATE v_sql_config USING IN SYSTIMESTAMP, v_logsession_id, c_n, c_to_table, c_n, c_to_screen, c_s, 0;
	EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
	--
	SELECT COUNT(*) INTO l_count FROM tetools.admin_logger_sessions WHERE sid = v_sid AND serial# = v_serial AND logon_user = v_logon_user AND audsid = v_audsid AND logon_time = v_logontime;
	IF    l_count != 1  THEN RAISE generic_error; END IF;
	--
	SELECT COUNT(*) INTO l_count FROM tetools.admin_logger_sessions WHERE logsession_id = v_logsession_id AND sid = v_sid AND serial# = v_serial AND logon_user = v_logon_user AND audsid = v_audsid AND logon_time = v_logontime;
    IF l_count != 1 THEN RAISE generic_error; END IF;
    --
    SELECT COUNT(*) INTO l_count FROM tetools.admin_logger_config WHERE logsession_id = v_logsession_id;
    IF l_count != 1 THEN RAISE generic_error; END IF;
	--
	v_incident_status := 'CLOSED';
	EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
	COMMIT;
	--
  EXCEPTION
     WHEN failure_in_calling                                                                                                 THEN
       DBMS_OUTPUT.PUT_LINE(l_context||'.'||v_this_object||': object '||v_caller||' called this procedure with unsupported parameter: '|| issue);
       ROLLBACK;
       RAISE;
    WHEN generic_error                                                                                                       THEN
      v_backtrace := DBMS_UTILITY.format_error_stack||CHR(10)||DBMS_UTILITY.format_error_backtrace;
	  ROLLBACK;
      BEGIN
        IF v_incident_id IS NOT NULL THEN
          v_incident_status := 'OPEN';
          EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
          COMMIT;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
      END;
	  RAISE;
    WHEN OTHERS                                                                                                              THEN
	  v_backtrace := DBMS_UTILITY.format_error_stack||CHR(10)||DBMS_UTILITY.format_error_backtrace;
	  ROLLBACK;
      BEGIN
        IF v_incident_id IS NOT NULL THEN
          v_incident_status := 'OPEN';
          EXECUTE IMMEDIATE v_upd_incident USING IN v_incident_status, v_incident_id;
          COMMIT;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
      END;
      RAISE;
	--
  END session_detail_incident;
  --
  -- /* PROCEDURE > load_session_details ---------------------------------------------------------------------------- V$SESSION ----- */
  --
  PROCEDURE load_session_details ( allow_null BOOLEAN DEFAULT FALSE )
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    l_logger_config          admin_logger_config%ROWTYPE;
    l_logger_sessions        admin_logger_sessions%ROWTYPE;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_count                  PLS_INTEGER;
	v_settings_id            PLS_INTEGER;
    v_sid                    PLS_INTEGER;
    v_serial                 PLS_INTEGER;
	v_logger_on              CHAR(1);
	v_batch_mode             CHAR(1);
	v_batch_id               PLS_INTEGER;
	v_logger_target          CHAR(1);
	v_debug                  CHAR(1);
	v_debug_target           CHAR(1);
	v_logcontext             VARCHAR2(4000);
  BEGIN
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
  	SELECT tetools.admin_logger.get_invoking_sid                                       INTO g_session_rt.sid            FROM DUAL;
	SELECT tetools.admin_logger.get_invoking_serial                                    INTO g_session_rt.serial#        FROM DUAL;
	SELECT tetools.admin_logger.get_audsid(g_session_rt.sid, g_session_rt.serial#)     INTO g_session_rt.audsid         FROM DUAL;
	SELECT tetools.admin_logger.get_logon_time(g_session_rt.sid, g_session_rt.serial#) INTO g_session_rt.logon_time     FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'SESSION_USER')                                      INTO g_session_rt.logon_user     FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'CURRENT_USER')                                      INTO g_session_rt.current_user   FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')                                    INTO g_session_rt.current_schema FROM DUAL;
	SELECT SYS_CONTEXT('USERENV', 'PROXY_USER')                                        INTO g_session_rt.proxy_user     FROM DUAL;
	--
	/* Make sure there is a row */ 
	SELECT COUNT(*) INTO l_count
	  FROM admin_logger_sessions
     WHERE          1 = 1
       AND sid        = g_session_rt.sid
       AND serial#    = g_session_rt.serial#
       AND logon_user = g_session_rt.logon_user
       AND audsid     = g_session_rt.audsid
       AND logon_time = g_session_rt.logon_time;
    --
	IF    l_count = 0       THEN
	  g_session_rt.logsession_id := 0                                         ;
	  g_config_rt.config_id      := 0                                         ;
      g_config_rt.logging_on     := c_false                                   ;
      g_config_rt.logging_target := c_to_table                                ;
	  g_config_rt.debug_on       := c_false                                   ;
	  g_config_rt.debug_target   := g_debug_target                            ;
	  g_config_rt.batch_mode     := c_s                                       ;
      g_logging_rt.log_batch     := 0                                         ;
      g_logging_rt.log_lines     := 0                                         ;
	  --
	  IF NOT allow_null THEN
	    RAISE missing_logsession;
	  END IF;
	  --
    ELSIF l_count = 1       THEN 
	  --
	  SELECT * INTO l_logger_sessions
	    FROM tetools.admin_logger_sessions
	   WHERE          1 = 1
         AND sid        = g_session_rt.sid
         AND serial#    = g_session_rt.serial#
         AND logon_user = g_session_rt.logon_user
         AND audsid     = g_session_rt.audsid
         AND logon_time = g_session_rt.logon_time;
	  --
	  SELECT * INTO l_logger_config
	    FROM tetools.ADMIN_LOGGER_CONFIG
	   WHERE logsession_id  = l_logger_sessions.logsession_id;
	  --
	  g_session_rt.logsession_id     := l_logger_sessions.logsession_id       ;
	  g_config_rt.config_id          := l_logger_config.config_id             ;
	  g_config_rt.logging_on         := char2bool(l_logger_config.logger_on)  ;
      g_config_rt.logging_target     := l_logger_config.logger_target         ;
      g_config_rt.debug_on           := char2bool(l_logger_config.debug_on)   ;
      g_config_rt.debug_target       := l_logger_config.debug_target          ;
	  g_config_rt.batch_mode         := l_logger_config.batch_mode            ;
	  --
	  IF l_logger_config.batch_mode = c_b THEN
	    IF   g_logging_rt.log_batch IS NULL
		  OR g_logging_rt.log_batch != l_logger_config.logbatch_id
		  OR g_logging_rt.log_lines IS NULL   THEN
		    EXECUTE IMMEDIATE q'[SELECT NVL(MAX(log_lines), 0)+1 FROM tetools.admin_logger_log WHERE logsession_id = :sid AND logbatch_id = :bid]'
			INTO g_logging_rt.log_lines USING l_logger_sessions.logsession_id, l_logger_config.logbatch_id;
		END IF;
	  ELSE
	    g_logging_rt.log_lines     := 0                                       ;
	  END IF;
      g_logging_rt.log_batch         := l_logger_config.logbatch_id           ;
	ELSIF l_count > 1 THEN
	  RAISE too_many_sessions;
	END IF;
	--
  EXCEPTION 
    WHEN missing_logsession                 THEN
	  session_detail_incident( issue => 'missing_id' );
	  --log_error_force ( context_in => l_context, data_in => v_this_object||': No registered logsessions found for this user. Crashing out.' );
      RAISE; 
    WHEN too_many_sessions                  THEN 
	  session_detail_incident( issue => 'extra_id' );
	  --log_error_force ( context_in => l_context, data_in => v_this_object||': Too many registered logsessions found for this user. Crashing out.' );
      RAISE; 
	--
  END load_session_details;
  --
  -- /* PROCEDURE > session_details ---------------------------------------------------------------------- LOAD_SESSION_DETAILS ----- */
  --
  PROCEDURE session_details
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
  BEGIN
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
	load_session_details(FALSE);
	--
  EXCEPTION 
    WHEN OTHERS                  THEN 
	  log_error_force ( context_in => l_context, data_in => v_this_object||': wrapper calling load_session_details failed.' );
	--
  END session_details;
  --
  -- /* PROCEDURE > session_details_revert -------------------------------------------------------------------------- V$SESSION ----- */
  --
  PROCEDURE session_details_revert(modus IN VARCHAR2, config_key IN VARCHAR2 DEFAULT NULL)
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    l_logger_config          admin_logger_config%ROWTYPE;
    l_logger_sessions        admin_logger_sessions%ROWTYPE;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_count                  PLS_INTEGER;
    v_sid                    PLS_INTEGER;
    v_serial                 PLS_INTEGER;
    v_audsid                 PLS_INTEGER;
	v_settings_id            PLS_INTEGER;
	v_backup                 VARCHAR2(6)   := 'BACKUP';
	v_restore                VARCHAR2(7)   := 'RESTORE';
	v_logger_on              CHAR(1);
	v_batch_mode             CHAR(1);
	v_logger_target          CHAR(1);
	v_debug                  CHAR(1);
	v_debug_target           CHAR(1);
	v_logcontext             VARCHAR2(4000);
  BEGIN
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
  	SELECT tetools.admin_logger.get_invoking_sid                     INTO v_sid            FROM DUAL;
	SELECT tetools.admin_logger.get_invoking_serial                  INTO v_serial         FROM DUAL;
	SELECT tetools.admin_logger.get_audsid(v_sid, v_serial)          INTO v_audsid         FROM DUAL;
	--
	/* Make sure there is a row */ 
	SELECT COUNT(*) INTO l_count
	  FROM admin_logger_sessions
     WHERE          1 = 1
       AND sid        = v_sid
       AND serial#    = v_serial
       AND audsid     = v_audsid;
    --
    IF UPPER(modus) = v_backup AND g_config_bck_rt.config_key IS NULL      THEN 
	  --
	  SELECT * INTO l_logger_sessions
	    FROM tetools.admin_logger_sessions
	   WHERE          1 = 1
         AND sid        = v_sid
         AND serial#    = v_serial
         AND audsid     = v_audsid;
	  --
	  SELECT * INTO l_logger_config
	    FROM tetools.ADMIN_LOGGER_CONFIG
	   WHERE logsession_id  = l_logger_sessions.logsession_id;
	  --
	  g_config_bck_rt.config_key     := config_key                            ;
	  g_config_bck_rt.config_id      := l_logger_config.config_id             ;
	  g_config_bck_rt.logging_on     := char2bool(l_logger_config.logger_on)  ;
      g_config_bck_rt.logging_target := l_logger_config.logger_target         ;
      g_config_bck_rt.debug_on       := char2bool(l_logger_config.debug_on)   ;
      g_config_bck_rt.debug_target   := l_logger_config.debug_target          ;
	  g_config_bck_rt.batch_mode     := l_logger_config.batch_mode            ;
      g_config_bck_rt.log_batch      := l_logger_config.logbatch_id           ;
	  --
	ELSIF UPPER(modus) = v_restore AND g_config_bck_rt.config_key = config_key THEN
	  --
	  g_config_rt.config_id          := g_config_bck_rt.config_id      ;
	  g_config_rt.logging_on         := g_config_bck_rt.logging_on     ;
      g_config_rt.logging_target     := g_config_bck_rt.logging_target ;
      g_config_rt.debug_on           := g_config_bck_rt.debug_on       ;
      g_config_rt.debug_target       := g_config_bck_rt.debug_target   ;
	  g_config_rt.batch_mode         := g_config_bck_rt.batch_mode     ;
      g_logging_rt.log_batch         := g_config_bck_rt.log_batch      ;
	  --
	  g_config_bck_rt.config_key     := NULL ;
	  g_config_bck_rt.config_id      := NULL ;
	  g_config_bck_rt.logging_on     := NULL ;
      g_config_bck_rt.logging_target := NULL ;
      g_config_bck_rt.debug_on       := NULL ;
      g_config_bck_rt.debug_target   := NULL ;
	  g_config_bck_rt.batch_mode     := NULL ;
      g_config_bck_rt.log_batch      := NULL ;
	  --
	  save_logger_config;
	  --
	END IF;
	--
  EXCEPTION 
    WHEN too_many_sessions                  THEN 
	  log_error_force ( context_in => l_context, data_in => v_this_object||': Too many registered logsessions found for this user. Crashing out.' );
	  RAISE;
	--
  END session_details_revert;
  --
  -- /* PROCEDURE > show_config ------------------------------------------------------------------------- ADMIN_LOGGER_SETTINGS ----- */
  --
  PROCEDURE show_config ( modus IN VARCHAR DEFAULT NULL )
  AS
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    l_logging_target         VARCHAR2(24);
    l_debug_target           VARCHAR2(24);
    v_result                 CLOB;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;

  BEGIN
	--
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    /* VALIDATE INPUT PARAMETERS */
    IF modus IS NOT NULL    THEN
	  IF NOT UPPER(modus) = c_helpme  THEN
    	v_result := 'Procedure was called with invalid/missing parameters.'||CHR(10);
		v_result := 'Parameters used: modus '||modus||'.'||CHR(10);
        RAISE failure_in_calling;
	  ELSE
	    RAISE get_help;
	  END IF;
    END IF;
	--
	SELECT DECODE(g_config_rt.logging_target, 'S', 'SCREEN', 'T', 'LOGGING TABLE') INTO l_logging_target FROM DUAL;
	SELECT DECODE(g_config_rt.debug_target,   'S', 'SCREEN', 'T', 'LOGGING TABLE') INTO l_debug_target   FROM DUAL;
	--
	DBMS_OUTPUT.ENABLE (1000000);
	DBMS_OUTPUT.PUT_LINE('CURRENT LOGGING SETTINGS FOR '||g_session_rt.logon_user);
	DBMS_OUTPUT.PUT_LINE('CONFIG_KEY     VALUE');
	DBMS_OUTPUT.PUT_LINE('-------------- -------------------------'                                  );
	DBMS_OUTPUT.PUT_LINE('logsession_id  '||TO_CHAR(g_session_rt.logsession_id)                      );
	DBMS_OUTPUT.PUT_LINE('sid            '||TO_CHAR(g_session_rt.sid)                                );
	DBMS_OUTPUT.PUT_LINE('serial#        '||TO_CHAR(g_session_rt.serial#)                            );
	DBMS_OUTPUT.PUT_LINE('audsid         '||TO_CHAR(g_session_rt.audsid)                             );
	DBMS_OUTPUT.PUT_LINE('logon_user     '||g_session_rt.logon_user                                  );
	DBMS_OUTPUT.PUT_LINE('batch_mode     '||g_config_rt.batch_mode                                   );
    DBMS_OUTPUT.PUT_LINE('LogBatch ID    '||g_logging_rt.log_batch                                   );
	DBMS_OUTPUT.PUT_LINE('current_user   '||g_session_rt.current_user                                );
	DBMS_OUTPUT.PUT_LINE('current_schema '||g_session_rt.current_schema                              );
	DBMS_OUTPUT.PUT_LINE('proxy_user     '||g_session_rt.proxy_user                                  );
	DBMS_OUTPUT.PUT_LINE('logon_time     '||TO_CHAR(g_session_rt.logon_time, 'YYYY-MM-DD HH24:MI:SS'));
	DBMS_OUTPUT.PUT_LINE('logging        '||BOOL2VC(g_config_rt.logging_on)                          );
    DBMS_OUTPUT.PUT_LINE('logging_target '||l_logging_target                                         );
	DBMS_OUTPUT.PUT_LINE('debug          '||BOOL2VC(g_config_rt.debug_on)                            );
    DBMS_OUTPUT.PUT_LINE('debug_target   '||l_debug_target                                           );
  --
  EXCEPTION
    WHEN failure_in_calling                                                                                                  THEN
      v_result := v_result||DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
	WHEN get_help                                                                                                            THEN
	  help('HELP SHC');
    WHEN OTHERS                                                                                                              THEN
      v_result := v_result||DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
      RAISE;
	--
  END show_config;
  --
  -- /* PROCEDURE > who_called --------------------------------------------------------------------------------- UTL_CALL_STACK ----- */
  --
  PROCEDURE who_called ( p_level IN NUMBER, p_trm_result OUT VARCHAR2 )
  AS
    v_caller utl_call_stack.unit_qualified_name;
    v_name   VARCHAR2(128);
  BEGIN
  --
    /* This procedure retrieves the calling component. */
    /* This information is used for troubleshooting and debugging and has no purpose for standard operational use. */
    -- step backwards though the call stack
    --      1 = current module = who_called function
    --      2 = the module that calls who_called
    --      3 = the caller!
    --v_caller := utl_call_stack.subprogram(2);
	v_caller     := utl_call_stack.subprogram(p_level);
    p_trm_result := utl_call_stack.concatenate_subprogram(v_caller);
  END who_called;
  --
  -- /* PROCEDURE > toggle_logging ----------------------------------------------------------------------- ADMIN_LOGGER_CONFIG ----- */
  --
  PROCEDURE toggle_logging  ( modus                   IN VARCHAR2 DEFAULT c_on, 
                              send_log_to_in          IN VARCHAR2 DEFAULT g_logging_target)
  IS
    PRAGMA                   AUTONOMOUS_TRANSACTION; 
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    v_session_id             INTEGER;
    v_logger_modus_bool      BOOLEAN;
    v_logger_modus_c         CHAR(1);
    v_debug_on               CHAR(1);
    v_result                 CLOB;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  BEGIN
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.toggle_logging', action_name => 'Toggle logging on or off for session.');
    --
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
  --
    /* VALIDATE INPUT PARAMETERS */
	IF modus IS NULL OR send_log_to_in IS NULL                  THEN
	  RAISE failure_in_calling;
	END IF;
    IF    UPPER(modus) NOT IN ( c_on, c_off, c_helpme )         THEN
      RAISE failure_in_calling;
	ELSIF UPPER(modus) = c_helpme                               THEN
	  RAISE get_help;
    END IF;
	IF UPPER(send_log_to_in) NOT IN ( c_to_table, c_to_screen ) THEN
      RAISE failure_in_calling;
    END IF;
    --
    /* Also set global flag, so that multiple calls in the same server call can use this and not select from the table. */ 
    --
    IF    UPPER(modus) = c_on   THEN
      g_config_rt.logging_on := c_true;
    ELSIF UPPER(modus) = c_off  THEN
      g_config_rt.logging_on := c_false;
    END IF;
    --
    g_config_rt.logging_target := UPPER(send_log_to_in);
    --
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
    --
    /* And set the table too */
    save_logger_config;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
  EXCEPTION
    WHEN failure_in_calling                                                                                                  THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := 'Procedure was called with invalid/missing parameters.'||CHR(10);
  	  v_result := v_result||'Parameters used: modus '||NVL(modus, 'NULL')||', send_log_to_in '||NVL(send_log_to_in, 'NULL')||'.'||CHR(10);
      v_result := v_result||DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
  WHEN get_help                                                                                                            THEN
    help('HELP TLO');
    WHEN OTHERS                                                                                                              THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
      RAISE;
  END toggle_logging;
  --
  -- /* PROCEDURE > toggle_debug ------------------------------------------------------------- ADMIN_LOGGER_CONFIG ----- */
  --
  PROCEDURE toggle_debug        ( modus                   IN VARCHAR2 DEFAULT c_off,
                                  set_debug_target        IN CHAR     DEFAULT g_debug_target )
  IS
    PRAGMA                   AUTONOMOUS_TRANSACTION;
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
    v_session_id             INTEGER;
	l_debug_on               CHAR(1);
	v_logger_modus_bool      BOOLEAN;
	v_logger_modus_c         CHAR(1);
    v_result                 CLOB;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  BEGIN
	--
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.toggle_debug', action_name => 'Toggle debug logging on or off for session.');
	--
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    /* VALIDATE INPUT PARAMETERS */
	IF modus IS NULL OR set_debug_target IS NULL                  THEN
	  RAISE failure_in_calling;
	END IF;
    IF    UPPER(modus) NOT IN ( c_on, c_off, c_helpme )           THEN
      RAISE failure_in_calling;
	ELSIF UPPER(modus) = c_helpme                                 THEN
	  RAISE get_help;
    END IF;
	IF UPPER(set_debug_target) NOT IN ( c_to_table, c_to_screen ) THEN
      RAISE failure_in_calling;
    END IF;
    --
	IF    UPPER(modus) = c_on  THEN
	  g_config_rt.debug_on := c_true;
	ELSIF UPPER(modus) = c_off THEN
	  g_config_rt.debug_on := c_false;
	END IF;
	--
	g_config_rt.debug_target := UPPER(set_debug_target);
	--
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
	--
	save_logger_config;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
  --
  EXCEPTION
    WHEN failure_in_calling                                                                                                  THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := 'Procedure was called with invalid/missing parameters.'||CHR(10);
  	  v_result := v_result||'Parameters used: modus '||NVL(modus, 'NULL')||', send_log_to_in '||NVL(set_debug_target, 'NULL')||'.'||CHR(10);
      v_result := v_result||DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
	WHEN get_help                                                                                                            THEN
	  help('HELP TLD');
    WHEN OTHERS                                                                                                              THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := v_result||DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
      RAISE;
	--
  END toggle_debug;
  --
  -- /* PROCEDURE > toggle_batch ------------------------------------------------------------- ADMIN_LOGGER_CONFIG ----- */
  --
  PROCEDURE toggle_batch     ( modus IN VARCHAR2 DEFAULT c_off, batch IN VARCHAR2 DEFAULT c_single )
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
	p_batch                  VARCHAR2(4);
	l_batch                  INTEGER;
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
	v_result                 CLOB;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  BEGIN
	--
    session_details;
	--
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.'||l_context, action_name => 'Retrieve, and set/unset a logbatch_id for grouping logmessages.');
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
	--
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    /* VALIDATE INPUT PARAMETERS */
	IF modus IS NULL OR batch IS NULL                        THEN
	  RAISE failure_in_calling;
	END IF;
    IF    UPPER(modus) NOT IN ( c_on, c_off, c_helpme )      THEN
      RAISE failure_in_calling;
	ELSIF UPPER(modus) = c_helpme                            then
	  RAISE get_help;
    END IF;
	IF UPPER(batch) NOT IN ( c_s, c_single, c_b, c_batch ) THEN
      RAISE failure_in_calling;
    END IF;
	--
	IF    UPPER(batch) = c_s OR UPPER(batch) = c_single THEN
	  p_batch := c_s;
	  g_config_rt.batch_mode := c_s;
	ELSIF UPPER(batch) = c_b OR UPPER(batch) = c_batch  THEN
	  p_batch := c_b;
	  g_config_rt.batch_mode := c_b;
	ELSIF UPPER(batch) = c_helpme                       THEN
	  RAISE get_help;
	ELSE
	  v_result := 'Procedure was called with invalid/missing parameters.'||CHR(10);
	  v_result := 'Parameters used: batch '||batch||', modus '||modus||CHR(10);
      RAISE failure_in_calling;
	END IF;
	--
    IF    UPPER(modus) = c_off                THEN
	  g_config_rt.batch_mode  := c_s;
	  g_logging_rt.log_batch  := 0;
	  g_logging_rt.log_lines  := 0;
	ELSIF UPPER(modus) = c_on                 THEN
	  --
	  IF   g_config_rt.batch_mode  IS NULL
		OR g_logging_rt.log_batch  IS NULL
        OR g_logging_rt.log_batch  <= 1       THEN
		  SELECT tetools.admin_logger_logbatch_seq.NEXTVAL INTO g_logging_rt.log_batch FROM dual;
		  g_logging_rt.log_lines  := 1;
	  END IF;
	  --
	END IF;
	--
	save_logger_config;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
	DBMS_APPLICATION_INFO.SET_MODULE(NULL,NULL);
  --
  EXCEPTION
    WHEN failure_in_calling                                                                                                  THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := 'Procedure was called with invalid/missing parameters.'||CHR(10);
  	  v_result := v_result||'Parameters used: modus '||NVL(modus, 'NULL')||', send_log_to_in '||NVL(batch, 'NULL')||'.'||CHR(10);
      v_result := v_result||DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': failure_in_calling '||CHR(10)||v_result );
	WHEN get_help                                                                                                            THEN
	  help('HELP TBI');
    WHEN OTHERS                                                                                                              THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  log_error_force ( context_in => l_context, data_in => v_this_object||': others '||CHR(10)||v_result );
      RAISE;
	--
  END toggle_batch;
  --
  -- /* PROCEDURE > exception_logging -------------------------------------------------- ADMIN_LOGGER_LOGGING_CLOB ----- */
  --
   PROCEDURE exception_logging ( context         IN VARCHAR2,
                                 data            IN CLOB,
								 callstack       IN CLOB,
							     category        IN VARCHAR2 ) 
   IS 
    PRAGMA AUTONOMOUS_TRANSACTION;
    c_callstack              VARCHAR2(4000)        := DBMS_UTILITY.format_call_stack ;
    l_logger_config          admin_logger_config%ROWTYPE;
    l_logger_sessions        admin_logger_sessions%ROWTYPE;
	l_logger_logs            admin_logger_log%ROWTYPE;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
    v_this_object            VARCHAR2(128);
	v_caller                 VARCHAR2(128);
	v_sql_logger             VARCHAR2(4000) := 'INSERT INTO TETOOLS.ADMIN_LOGGER_LOG (created_on, logsession_id, logbatch_id, log_category, log_lines, context, text, callstack) VALUES (:1, :2, :3, :4, :5, :6, :7, :8)';
	--
   BEGIN
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.exception_logging', action_name => 'Logging encountered exception for session.');
	--
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
	DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
    --
	--toggle_batch(batch => 'S', modus => 'ON');
    --
    EXECUTE IMMEDIATE v_sql_logger USING IN SYSTIMESTAMP, g_session_rt.logsession_id, g_logging_rt.log_batch, category, g_logging_rt.log_lines, context, data, DBMS_UTILITY.format_call_stack;
    COMMIT;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
  EXCEPTION
    WHEN OTHERS THEN
	  DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  ROLLBACK;
      RAISE;
  END exception_logging; 
  --
  -- /* PROCEDURE > internal_logging --------------------------------------------------- ADMIN_LOGGER_LOGGING_CHAR ----- */
  --
  PROCEDURE internal_logging ( context_in      IN VARCHAR2,
                               data_in         IN VARCHAR2,
							   logcategory     IN VARCHAR2,
						       override_target IN CHAR    DEFAULT g_override_target,
						       override_in     IN BOOLEAN DEFAULT g_debug_on )
  IS 
    PRAGMA AUTONOMOUS_TRANSACTION; 
    c_callstack              VARCHAR2(4000)     := DBMS_UTILITY.format_call_stack ;
    l_logger_config          admin_logger_config%ROWTYPE;
    l_logger_sessions        admin_logger_sessions%ROWTYPE;
	l_logger_logs            admin_logger_log%ROWTYPE;
    l_count_ses              PLS_INTEGER;
    l_count_log              PLS_INTEGER;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
    l_log_it                 BOOLEAN                     := override_in OR admin_logger.char2bool(logging_is_on (l_logger_sessions.logsession_id)) OR admin_logger.char2bool(debug_is_on (l_logger_sessions.logsession_id)); 
	l_override_target        CHAR(1)                     := override_target;
	v_result                 CLOB;
	v_backtrace              CLOB;
    v_this_object            VARCHAR2(128);
	v_caller                 VARCHAR2(128);
	v_sql_logger             VARCHAR2(4000) := 'INSERT INTO TETOOLS.ADMIN_LOGGER_LOG (created_on, logsession_id, logbatch_id, log_category, log_lines, context, text, callstack) VALUES (:1, :2, :3, :4, :5, :6, :7, :8)';
  --
  BEGIN
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.internal_logging', action_name => 'Logging procedure for session.');
    --
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
    --
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
    --
    IF g_logging_rt.log_batch = 0 THEN
      toggle_batch(batch => 'S', modus => 'ON');
    END IF;
    --
    IF l_log_it       THEN
    --
      /* Make sure there is a row */
      SELECT COUNT(*) INTO l_count_ses
        FROM admin_logger_sessions ses
        JOIN admin_logger_config   con ON ses.logsession_id = con.logsession_id
       WHERE              1 = 1
         AND ses.logsession_id = g_session_rt.logsession_id;
      --
      /* Make sure there is a row for logs */
      SELECT COUNT(*) INTO l_count_log
        FROM admin_logger_log LOG
       WHERE                 1 = 1
         AND log.logsession_id = g_session_rt.logsession_id;
  	  --
      IF l_count_ses = 1   THEN 
        SELECT * INTO l_logger_sessions
          FROM admin_logger_sessions
         WHERE             1 = 1
           AND logsession_id = g_session_rt.logsession_id;
        --
  	    SELECT * INTO l_logger_config
  	      FROM admin_logger_config
  	     WHERE             1 = 1
  	       AND logsession_id = g_session_rt.logsession_id;
        --
        IF override_in = FALSE THEN
  	      IF logcategory = 'DEBUG' THEN
  		    IF    g_config_rt.debug_on     THEN
              l_override_target    := g_config_rt.debug_target;
  		    ELSE
  		      l_log_it := c_false;
  		    END IF;
  		  ELSE
            IF    g_config_rt.debug_on     THEN
              l_override_target    := g_config_rt.debug_target;
            ELSIF g_config_rt.logging_on   THEN
              l_override_target    := g_config_rt.logging_target;
  		    ELSE
  		      l_override_target    := g_override_target;
            END IF;
          END IF;
        ELSE
          l_override_target    := g_override_target;
        END IF;
        --
      END IF;
    END IF; 
    --
    IF l_log_it AND l_count_ses = 1  THEN
      --
	  IF    l_override_target = c_to_screen  THEN
	    put_line (data_in); 
	  ELSIF l_override_target = c_to_table   THEN
	    EXECUTE IMMEDIATE v_sql_logger USING IN SYSTIMESTAMP, l_logger_config.logsession_id, g_logging_rt.log_batch, logcategory, g_logging_rt.log_lines, context_in, data_in, DBMS_UTILITY.format_call_stack;
		COMMIT;
		--
  	    IF    g_config_rt.batch_mode = c_b THEN
  	      g_logging_rt.log_lines  := g_logging_rt.log_lines + 1;
	    ELSIF g_config_rt.batch_mode = c_s THEN
	      toggle_batch(batch => 'S', modus => 'OFF');
        END IF;
  	  ELSE
  	    RAISE corrupt_logger_target;
	  END IF;
  	  --
    END IF;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
  --
  EXCEPTION
    WHEN corrupt_logger_target                                                                            THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result    := DBMS_UTILITY.format_error_stack;
	  v_backtrace := DBMS_UTILITY.format_error_backtrace;
	  ROLLBACK;
	  BEGIN
        exception_logging (context => context_in, data => v_caller||': corrupt_logger_target '||CHR(10)||v_result, callstack => DBMS_UTILITY.format_error_stack, category => 'ERROR');
	  EXCEPTION WHEN OTHERS THEN
	    NULL;
	  END;
      RAISE;
    WHEN OTHERS                                                                                            THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  v_backtrace := DBMS_UTILITY.format_error_backtrace;
	  ROLLBACK;
	  BEGIN
        exception_logging (context => context_in, data => v_caller||': others '||CHR(10)||v_result, callstack => DBMS_UTILITY.format_error_stack, category => 'ERROR');
	  EXCEPTION WHEN OTHERS THEN
	    NULL;
	  END;
      RAISE;
  END internal_logging; 
  --
  -- /* PROCEDURE > internal_logging --------------------------------------------------- ADMIN_LOGGER_LOGGING_CLOB ----- */
  --
   PROCEDURE internal_logging ( context_in      IN VARCHAR2,
                                data_in         IN CLOB,
							    logcategory     IN VARCHAR2,
							    override_target IN CHAR    DEFAULT g_override_target,
							    override_in     IN BOOLEAN DEFAULT g_debug_on ) 
   IS 
    PRAGMA AUTONOMOUS_TRANSACTION;
    c_callstack              VARCHAR2(4000)        := DBMS_UTILITY.format_call_stack ;
    l_logger_config          admin_logger_config%ROWTYPE;
    l_logger_sessions        admin_logger_sessions%ROWTYPE;
	l_logger_logs            admin_logger_log%ROWTYPE;
    l_count_ses              PLS_INTEGER;
    l_count_log              PLS_INTEGER;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
    l_log_it                 BOOLEAN                     := override_in OR admin_logger.char2bool(logging_is_on (l_logger_sessions.logsession_id)) OR admin_logger.char2bool(debug_is_on (l_logger_sessions.logsession_id)); 
	l_override_target        CHAR(1)                     := override_target;
	l_null                   CHAR(1);
	v_result                 CLOB;
	v_backtrace              CLOB;
    v_this_object            VARCHAR2(128);
	v_caller                 VARCHAR2(128);
	v_sql_logger             VARCHAR2(4000) := 'INSERT INTO TETOOLS.ADMIN_LOGGER_LOG (created_on, logsession_id, logbatch_id, log_category, log_lines, context, text, callstack) VALUES (:1, :2, :3, :4, :5, :6, :7, :8)';
	--
   BEGIN
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.internal_logging', action_name => 'Logging procedure for session.');
	--
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_old_client);
	DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'Called by '||v_caller);
    --
    IF g_logging_rt.log_batch = 0 THEN
      toggle_batch(batch => 'S', modus => 'ON');
    END IF;
	--
    IF l_log_it       THEN
      /* Make sure there is a row for sessions */
      SELECT COUNT(*) INTO l_count_ses
        FROM admin_logger_sessions ses
        JOIN admin_logger_config   con ON ses.logsession_id = con.logsession_id
	   WHERE              1 = 1
	     AND ses.logsession_id = g_session_rt.logsession_id;
	  --
	  /* Make sure there is a row for logs */
	  SELECT COUNT(*) INTO l_count_log
	    FROM admin_logger_log LOG
	   WHERE              1 = 1
	     AND log.logsession_id = g_session_rt.logsession_id;
	  --
      IF l_count_ses = 1   THEN 
        --
        SELECT * INTO l_logger_sessions
          FROM admin_logger_sessions
         WHERE             1 = 1
           AND logsession_id = g_session_rt.logsession_id;
        --
        SELECT * INTO l_logger_config
          FROM admin_logger_config
         WHERE             1 = 1
           AND logsession_id = g_session_rt.logsession_id;
        --
	    IF override_in = FALSE THEN
		  IF logcategory = 'DEBUG' THEN
	        IF    g_config_rt.debug_on     THEN
              l_override_target    := g_config_rt.debug_target;
	        ELSE
              l_log_it := c_false;
	        END IF;
	      ELSE
	        IF    g_config_rt.debug_on     THEN
              l_override_target    := g_config_rt.debug_target;
            ELSIF g_config_rt.logging_on   THEN
              l_override_target    := g_config_rt.logging_target;
            ELSE
              l_override_target    := g_override_target;
            END IF;
          END IF;
	    ELSE
	      l_override_target    := g_override_target;
	    END IF;
		--
      END IF;
    END IF;
    --
    IF l_log_it AND l_count_ses = 1  THEN
      --
	  IF    l_override_target = c_to_screen  THEN
	    put_line (data_in); 
	  ELSIF l_override_target = c_to_table   THEN
	    EXECUTE IMMEDIATE v_sql_logger USING IN SYSTIMESTAMP, l_logger_config.logsession_id, g_logging_rt.log_batch, logcategory, g_logging_rt.log_lines, context_in, data_in, DBMS_UTILITY.format_call_stack;
		COMMIT;
		--
  	    IF    g_config_rt.batch_mode = c_b THEN
  	      g_logging_rt.log_lines  := g_logging_rt.log_lines + 1;
	    ELSIF g_config_rt.batch_mode = c_s THEN
	      toggle_batch(batch => 'S', modus => 'OFF');
        END IF;
  	  ELSE
  	    RAISE corrupt_logger_target;
	  END IF;
  	  --
    END IF;
    --
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
  EXCEPTION
    WHEN corrupt_logger_target                                                                            THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  v_backtrace := DBMS_UTILITY.format_error_backtrace;
	  ROLLBACK;
	  BEGIN
        exception_logging (context => context_in, data => v_caller||': corrupt_logger_target '||CHR(10)||v_result, callstack => DBMS_UTILITY.format_error_stack, category => 'ERROR');
	  EXCEPTION WHEN OTHERS THEN
	    NULL;
	  END;
      RAISE;
    WHEN OTHERS                                                                                            THEN
      DBMS_APPLICATION_INFO.SET_CLIENT_INFO(l_old_client);
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  v_result := DBMS_UTILITY.format_error_stack;
	  v_backtrace := DBMS_UTILITY.format_error_backtrace;
	  ROLLBACK;
	  BEGIN
        exception_logging (context => context_in, data => v_caller||': others '||CHR(10)||v_result, callstack => DBMS_UTILITY.format_error_stack, category => 'ERROR');
	  EXCEPTION WHEN OTHERS THEN
	    NULL;
	  END;
      RAISE;
  END internal_logging;
  --
  --
  --
  FUNCTION LOG_RUNTIME (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
  IS
  BEGIN
    LOG_RUNTIME (context_in, data_in); 
    RETURN 1; 
  END LOG_RUNTIME;
--
PROCEDURE LOG_RUNTIME (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'RUNTIME', l_override_target, override_in => c_false); 
	--
  END LOG_RUNTIME;
--
PROCEDURE LOG_RUNTIME (context_in IN VARCHAR2, data_in IN CLOB)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'RUNTIME', l_override_target, override_in => c_false); 
	--
  END LOG_RUNTIME; 
--
PROCEDURE LOG_RUNTIME (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, bool2vc (data_in), 'RUNTIME', l_override_target, override_in => c_false); 
	--
  END LOG_RUNTIME; 
--
PROCEDURE LOG_RUNTIME (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask )
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'RUNTIME', l_override_target, override_in => c_false); 
	--
  END LOG_RUNTIME; 
--
--
--
FUNCTION LOG_INFO (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
IS
BEGIN
  LOG_INFO (context_in, data_in); 
  RETURN 1; 
END LOG_INFO;
--
PROCEDURE LOG_INFO (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    -- 
    internal_logging (context_in, data_in, 'INFO', l_override_target, override_in => c_false); 
	--
  END LOG_INFO;
--
PROCEDURE LOG_INFO (context_in IN VARCHAR2, data_in IN CLOB)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'INFO', l_override_target, override_in => c_false); 
	--
  END LOG_INFO; 
--
PROCEDURE LOG_INFO (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, bool2vc (data_in), 'INFO', l_override_target, override_in => c_false); 
	--
  END LOG_INFO; 
--
PROCEDURE LOG_INFO (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask )
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'INFO', l_override_target, override_in => c_false); 
	--
  END LOG_INFO; 
--
--
--
FUNCTION LOG_WARNING (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
IS
BEGIN
  LOG_WARNING (context_in, data_in); 
  RETURN 1; 
END LOG_WARNING;
--
PROCEDURE LOG_WARNING (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'WARNING', l_override_target, override_in => c_false); 
	--
  END LOG_WARNING;
--
PROCEDURE LOG_WARNING (context_in IN VARCHAR2, data_in IN CLOB)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'WARNING', l_override_target, override_in => c_false);  
	--
  END LOG_WARNING; 
--
PROCEDURE LOG_WARNING (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, bool2vc (data_in), 'WARNING', l_override_target, override_in => c_false); 
	--
  END LOG_WARNING; 
--
PROCEDURE LOG_WARNING (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask )
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    -- 
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'WARNING', l_override_target, override_in => c_false); 
	--
  END LOG_WARNING; 
--
--
--
FUNCTION  LOG_ERROR (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
IS
BEGIN
  LOG_ERROR (context_in, data_in); 
  RETURN 1; 
END LOG_ERROR;
--
PROCEDURE LOG_ERROR (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'ERROR', l_override_target, override_in => c_false);
	--
  END LOG_ERROR;
--
PROCEDURE LOG_ERROR (context_in IN VARCHAR2, data_in IN CLOB)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'ERROR', l_override_target, override_in => c_false);
	--
  END LOG_ERROR; 
--
PROCEDURE LOG_ERROR (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, bool2vc (data_in), 'ERROR', l_override_target, override_in => c_false);
	--
  END LOG_ERROR; 
--
PROCEDURE LOG_ERROR (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask )
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'ERROR', l_override_target, override_in => c_false);
	--
  END LOG_ERROR;
--
--
--
FUNCTION  LOG_DEBUG (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
IS
BEGIN
  LOG_DEBUG (context_in, data_in); 
  RETURN 1; 
END LOG_DEBUG;
--
PROCEDURE LOG_DEBUG (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'DEBUG', l_override_target, override_in => c_false); 
	--
  END LOG_DEBUG;
--
PROCEDURE LOG_DEBUG (context_in IN VARCHAR2, data_in IN CLOB)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, data_in, 'DEBUG', l_override_target, override_in => c_false); 
	--
  END LOG_DEBUG; 
--
PROCEDURE LOG_DEBUG (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, bool2vc (data_in), 'DEBUG', l_override_target, override_in => c_false); 
	--
  END LOG_DEBUG; 
--
PROCEDURE LOG_DEBUG (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask )
  IS
	l_override_target        VARCHAR2 (1);
  BEGIN
    --
    session_details;
	--
	IF    g_config_rt.debug_on              THEN
      l_override_target    := g_config_rt.debug_target;
    ELSE
      l_override_target    := g_config_rt.logging_target;
    END IF;
    --
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'DEBUG', l_override_target, override_in => c_false); 
	--
  END LOG_DEBUG; 
--
--
--
FUNCTION LOG_RUNTIME_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
IS
BEGIN
  LOG_RUNTIME_FORCE (context_in, data_in); 
  RETURN 1; 
END LOG_RUNTIME_FORCE;
--
PROCEDURE LOG_RUNTIME_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2)
  IS
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
    --
    internal_logging (context_in, data_in, 'RUNTIME', c_to_table, override_in => c_true);
	--
  END LOG_RUNTIME_FORCE;
--
PROCEDURE LOG_RUNTIME_FORCE (context_in IN VARCHAR2, data_in IN CLOB)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'RUNTIME', c_to_table, override_in => c_true);
	--
  END LOG_RUNTIME_FORCE;
--
PROCEDURE LOG_RUNTIME_FORCE (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, bool2vc (data_in), 'RUNTIME', c_to_table, override_in => c_true); 
	--
  END LOG_RUNTIME_FORCE; 
--
PROCEDURE LOG_RUNTIME_FORCE (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask)
  IS 
    v_logbatch_id            PLS_INTEGER := g_logging_rt.log_batch;
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'RUNTIME', c_to_table, override_in => c_true); 
	--
  END LOG_RUNTIME_FORCE;
--
--
--
FUNCTION  LOG_INFO_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2 ) RETURN PLS_INTEGER
IS
BEGIN
  LOG_INFO_FORCE (context_in, data_in); 
  RETURN 1; 
END LOG_INFO_FORCE;
--
PROCEDURE LOG_INFO_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'INFO', c_to_table, override_in => c_true);
	--
  END LOG_INFO_FORCE;
--
PROCEDURE LOG_INFO_FORCE (context_in IN VARCHAR2, data_in IN CLOB)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'INFO', c_to_table, override_in => c_true);
	--
  END LOG_INFO_FORCE;
--
PROCEDURE LOG_INFO_FORCE (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, bool2vc (data_in), 'INFO', c_to_table, override_in => c_true);
	--
  END LOG_INFO_FORCE; 
--
PROCEDURE LOG_INFO_FORCE (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'INFO', c_to_table, override_in => c_true); 
	--
  END LOG_INFO_FORCE;
--
--
--
FUNCTION  LOG_WARNING_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER
IS
BEGIN
  LOG_WARNING_FORCE (context_in, data_in); 
  RETURN 1; 
END LOG_WARNING_FORCE;
--
PROCEDURE LOG_WARNING_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2)
  IS
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'WARNING', c_to_table, override_in => c_true); 
	--
  END LOG_WARNING_FORCE;
--
PROCEDURE LOG_WARNING_FORCE (context_in IN VARCHAR2, data_in IN CLOB)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'WARNING', c_to_table, override_in => c_true);
	--
  END LOG_WARNING_FORCE;
--
PROCEDURE LOG_WARNING_FORCE (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
    --
    internal_logging (context_in, bool2vc (data_in), 'WARNING', c_to_table, override_in => c_true); 
	--
  END LOG_WARNING_FORCE; 
--
PROCEDURE LOG_WARNING_FORCE (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'WARNING', c_to_table, override_in => c_true); 
	--
  END LOG_WARNING_FORCE;
--
--
--
FUNCTION  LOG_ERROR_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2) RETURN PLS_INTEGER 
IS
BEGIN
  LOG_ERROR_FORCE (context_in, data_in); 
  RETURN 1; 
END LOG_ERROR_FORCE;
--
PROCEDURE LOG_ERROR_FORCE (context_in IN VARCHAR2, data_in IN VARCHAR2) 
  IS
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'ERROR', c_to_table, override_in => c_true); 
	--
  END LOG_ERROR_FORCE;
--
PROCEDURE LOG_ERROR_FORCE (context_in IN VARCHAR2, data_in IN CLOB)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
	--
    internal_logging (context_in, data_in, 'ERROR', c_to_table, override_in => c_true);
	--
  END LOG_ERROR_FORCE;
--
PROCEDURE LOG_ERROR_FORCE (context_in IN VARCHAR2, data_in IN BOOLEAN)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
    --
    internal_logging (context_in, bool2vc (data_in), 'ERROR', c_to_table, override_in => c_true); 
	--
  END LOG_ERROR_FORCE; 
--
PROCEDURE LOG_ERROR_FORCE (context_in IN VARCHAR2, data_in IN DATE, format_in IN VARCHAR2 DEFAULT c_date_mask)
  IS 
	v_token                  VARCHAR2(5)  := gen_token;
  BEGIN
    --
    session_details;
    --
    internal_logging (context_in, TO_CHAR (data_in, format_in), 'ERROR', c_to_table, override_in => c_true); 
	--
  END LOG_ERROR_FORCE;
  --
  -- /* PROCEDURES > clear_session_entries ------------------------------------------------ ADMIN_LOGGER_SESSIONS ----- */
  --
  PROCEDURE clear_session_entries ( before_in IN VARCHAR2 DEFAULT NULL ) 
  IS
    PRAGMA                   AUTONOMOUS_TRANSACTION; 
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
	v_caller                 VARCHAR2(128);
    v_before_in              VARCHAR2(24) := TO_CHAR(SYSDATE, 'YYYY-MM-DD');
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	v_check_date             DATE;
    v_result                 CLOB;
    sess_del_sql             CLOB := 'DELETE FROM tetools.admin_logger_sessions WHERE logsession_id = :1';
    conf_del_sql             CLOB := 'DELETE FROM tetools.admin_logger_config WHERE logsession_id = :1';
	--
	CURSOR c_old_sessions(p_logondate IN VARCHAR2) IS
	WITH cte_sessions AS (
      SELECT SID
           , SERIAL#
           , AUDSID
           , LOGON_USER AS "USERNAME"
           , LOGON_TIME
        FROM ADMIN_LOGGER_SESSIONS
    minus
    SELECT SID
         , SERIAL#
         , AUDSID
         , USERNAME
         , LOGON_TIME
      FROM V$SESSION
    )
    ,    cte_als AS (
    SELECT als.LOGSESSION_ID
      FROM ADMIN_LOGGER_SESSIONS als
      JOIN CTE_sessions          ses ON als.SID = ses.SID AND als.SERIAL# = ses.SERIAL# AND als.AUDSID = ses.AUDSID AND als.LOGON_TIME = ses.LOGON_TIME
     WHERE TRUNC( als.LOGON_TIME) < TO_DATE(p_logondate, 'YYYY-MM-DD') - 3
    )
    SELECT LOGSESSION_ID FROM cte_als ORDER BY 1;
  --
  BEGIN
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.clear_log_entries', action_name => 'Cleanup logging for session.');
	--
    IF before_in IS NOT NULL THEN
	  IF UPPER(before_in) = c_helpme  THEN
        RAISE get_help;
	  ELSE
	    v_check_date := TO_DATE(before_in, c_date_mask);
	  END IF;
	  --
	  IF v_check_date IS NOT NULL  THEN
        v_before_in := TO_CHAR(TO_DATE(before_in, c_date_mask), c_date_mask);
	  ELSE
	    RAISE failure_in_calling;
	  END IF;
    END IF;
	--
  	FOR r_row IN c_old_sessions(v_before_in)
    LOOP
	  --
	  EXECUTE IMMEDIATE conf_del_sql USING r_row.logsession_id;
	  EXECUTE IMMEDIATE sess_del_sql USING r_row.logsession_id;
	  --
    END LOOP;
	--
    COMMIT;
	--
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
  EXCEPTION
    WHEN failure_in_calling                                                                                                  THEN
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
      v_result := DBMS_UTILITY.format_error_stack;
      log_error_force(l_context, v_this_object||': '||v_result);
    WHEN get_help                                                                                                            THEN
      help('HELP CSE');
    WHEN OTHERS                                                                                                              THEN
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
      log_error_force(l_context, v_this_object||': '||DBMS_UTILITY.format_error_stack);
      RAISE;
  --
  END clear_session_entries; 
  --
  -- /* PROCEDURES > clear_log_entries ----------------------------------------------------- ADMIN_LOGGER_LOGGING ----- */
  --
  PROCEDURE clear_log_entries ( before_in IN VARCHAR2 DEFAULT NULL ) 
  IS
    PRAGMA                   AUTONOMOUS_TRANSACTION; 
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    v_this_object            VARCHAR2(128);
	v_caller                 VARCHAR2(128);
	v_check_date             DATE;
    v_before_in              VARCHAR2(24) := TO_CHAR(SYSDATE, 'YYYY-MM-DD');
    all_del_sql              CLOB := 'DELETE FROM tetools.admin_logger_log WHERE created_on <= TO_DATE(:1, ''YYYY-MM-DD'')';
    v_result                 CLOB;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
	--
  BEGIN
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.clear_log_entries', action_name => 'Cleanup logging for session.');
	--
    IF before_in IS NOT NULL THEN
	  IF UPPER(before_in) = c_helpme  THEN
        RAISE get_help;
	  ELSE
	    v_check_date := TO_DATE(before_in, c_date_mask);
	  END IF;
	  --
	  IF v_check_date IS NOT NULL  THEN
        v_before_in := TO_CHAR(TO_DATE(before_in, c_date_mask), c_date_mask);
	  ELSE
	    RAISE failure_in_calling;
	  END IF;
    END IF;
    --
    EXECUTE IMMEDIATE all_del_sql USING v_before_in;
    --
    COMMIT;
	--
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
    --
  EXCEPTION
    WHEN failure_in_calling                                                                                                  THEN
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
      v_result := DBMS_UTILITY.format_error_stack;
      log_error_force(l_context, v_this_object||': '||v_result);
    WHEN get_help                                                                                                            THEN
      help('HELP CLS');
    WHEN OTHERS                                                                                                              THEN
      DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
      log_error_force(l_context, v_this_object||': '||DBMS_UTILITY.format_error_stack);
      RAISE;
	--
  END clear_log_entries; 
  --
  -- /* PROCEDURES > put_lines ---------------------------------------------------------------------- DBMS_OUTPUT ----- */
  --
   PROCEDURE put_line (data_in IN VARCHAR2) 
   IS 
   BEGIN 
      DBMS_OUTPUT.put_line (data_in); 
   END put_line; 
  --
   PROCEDURE put_line (data_in IN DATE,format_in IN VARCHAR2 DEFAULT c_date_mask ) 
   IS 
   BEGIN 
      DBMS_OUTPUT.put_line (TO_CHAR (data_in, format_in)); 
   END put_line; 
  --
   PROCEDURE put_line (data_in IN BOOLEAN) 
   IS 
   BEGIN 
      DBMS_OUTPUT.put_line (bool2vc (data_in)); 
   END put_line; 
  --
   PROCEDURE put_line (title_in IN VARCHAR2, data_in IN BOOLEAN) 
   IS 
   BEGIN 
      DBMS_OUTPUT.put_line ( title_in || ' - ' || bool2vc (data_in)); 
   END put_line; 
  --
  PROCEDURE put_line ( clob_in IN CLOB ) 
  IS 
    l_context                VARCHAR2(128) := $$PLSQL_UNIT;
    l_lines                  DBMS_SQL.varchar2s;
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    l_old_module             VARCHAR2(64);
    l_old_action             VARCHAR2(64);
    l_old_client             VARCHAR2(64);
    --
	PROCEDURE print_clob ( p_clob_in IN CLOB) is
      p_clob         CLOB;
      l_offset       PLS_INTEGER:=1;
      l_line         VARCHAR2(32767);
      l_total_length PLS_INTEGER := DBMS_LOB.GETLENGTH(p_clob);
      l_line_length  PLS_INTEGER;
      l_cnt          NUMBER := 0;
      l_len          NUMBER := 0;
    BEGIN
	  IF p_clob_in IS NULL THEN RETURN; END IF;
	  p_clob := p_clob_in;
      l_total_length := LENGTH(p_clob);
      --
	  WHILE l_offset <= DBMS_LOB.GETLENGTH(p_clob_in) LOOP
	    l_line := DBMS_LOB.SUBSTR(p_clob_in, 4000, l_offset);
		--
		IF l_line IS NULL THEN EXIT; END IF;
		DBMS_OUTPUT.PUT_LINE(l_line);
		l_offset := l_offset + LENGTH(l_line);
	  END LOOP;
    END;
	--
  BEGIN
    --
    DBMS_APPLICATION_INFO.READ_MODULE(l_old_module, l_old_action);
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'ADMIN_LOGGER.put_line', action_name => 'Internal procedure for logging.');
	--
    session_details;
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
	print_clob(clob_in);
	--
    DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
  EXCEPTION 
    WHEN NO_DATA_FOUND OR VALUE_ERROR       THEN 
	  DBMS_APPLICATION_INFO.SET_MODULE(l_old_module,l_old_action);
	  log_error_force ( context_in => l_context, data_in => v_this_object||': No data found or value error.' );
	  RAISE;
  END put_line; 
  --
  -- /* PROCEDURE > initialize --------------------------------------------------------------- ADMIN_LOGGER_SETTINGS ----- */
  --
  PROCEDURE initialize 
  IS 
    PRAGMA                   AUTONOMOUS_TRANSACTION; 
    l_count                  PLS_INTEGER;
    l_log_settings           admin_logger_config%ROWTYPE;
	v_yes                    VARCHAR2(3) := 'YES';
	v_y                      CHAR(1)     := 'Y';
	v_no                     VARCHAR2(2) := 'NO';
	v_n                      CHAR(1)     := 'N';
	v_true                   BOOLEAN     := TRUE;
	v_false                  BOOLEAN     := FALSE;
	l_depth                  PLS_INTEGER;
	l_lvl_object             PLS_INTEGER;
	l_lvl_caller             PLS_INTEGER;
    v_logsession_id          PLS_INTEGER;
    v_logger_on              CHAR(1);
	l_null                   CHAR(1);
    v_batch_id               PLS_INTEGER;
	v_proxy_user             VARCHAR2(128) := 'NULL';
    v_this_object            VARCHAR2(128);
    v_caller                 VARCHAR2(128);
	v_context_filter         VARCHAR2(4000);
    v_sql_config             VARCHAR2(4000);
    v_sql_sessions           VARCHAR2(4000);
	--
  BEGIN
  --
	load_session_details(TRUE);
    --
	l_depth := UTL_CALL_STACK.dynamic_depth;
	--
	IF l_depth = 1 THEN
	  l_lvl_object := l_depth;
	  l_lvl_caller := l_depth;
	ELSIF l_depth = 2 THEN
	  l_lvl_object := l_depth -1;
	  l_lvl_caller := l_depth;
	ELSIF l_depth > 1 THEN
	  l_lvl_object := 2;
	  l_lvl_caller := l_depth -1;
	END IF;
	--
    who_called(l_lvl_object, v_this_object);
	who_called(l_lvl_caller, v_caller);
	--
	v_sql_sessions := 'INSERT INTO TETOOLS.ADMIN_LOGGER_SESSIONS (created_on, sid, serial#, audsid, logon_user, logon_time, current_user, current_schema, proxy_user) VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9)';
	v_sql_config   := 'INSERT INTO TETOOLS.ADMIN_LOGGER_CONFIG (created_on, logsession_id, logger_on, logger_target, debug_on, debug_target, batch_mode, logbatch_id) VALUES (:1, :2, :3, :4, :5, :6, :7, :8)';
	--
	--
    /* Make sure there is a row */ 
    SELECT COUNT (*) INTO l_count
      FROM admin_logger_config
     WHERE             1 = 1
       AND logsession_id = g_session_rt.logsession_id;
	--
    IF l_count = 0       THEN
      --
      IF g_session_rt.proxy_user  IS NULL THEN
        EXECUTE IMMEDIATE v_sql_sessions || ' RETURNING LOGSESSION_ID INTO :NEW_SESSION' USING IN SYSTIMESTAMP, g_session_rt.sid, g_session_rt.serial#, g_session_rt.audsid, g_session_rt.logon_user, g_session_rt.logon_time, g_session_rt.current_user, g_session_rt.current_schema, l_null, OUT v_logsession_id;
      ELSE
	    EXECUTE IMMEDIATE v_sql_sessions || ' RETURNING LOGSESSION_ID INTO :NEW_SESSION' USING IN SYSTIMESTAMP, g_session_rt.sid, g_session_rt.serial#, g_session_rt.audsid, g_session_rt.logon_user, g_session_rt.logon_time, g_session_rt.current_user, g_session_rt.current_schema, g_session_rt.proxy_user, OUT v_logsession_id;
      END IF;
	  --
	  EXECUTE IMMEDIATE v_sql_config USING IN SYSTIMESTAMP, v_logsession_id, v_n, c_to_table, v_n, g_config_rt.debug_target, g_config_rt.batch_mode, g_logging_rt.log_batch;
	  --
      COMMIT;
    END IF; 
   END initialize; 
BEGIN 
   initialize;
END admin_logger;
/
