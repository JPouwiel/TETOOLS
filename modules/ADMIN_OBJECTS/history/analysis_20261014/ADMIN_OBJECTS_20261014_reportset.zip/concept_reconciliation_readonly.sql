-- CONCEPT C02: read-only reconciliation example using existing ledger.
-- Oracle 19c; PDB-local; run as TETOOLS. No DML, commit, or installation.
-- Not executed. This example does not fix the legacy ledger identity.
-- It deliberately limits scope to non-generated top-level objects.
-- :p_module must be an exact non-NULL registered module name.
-- Unknown/unassigned schema objects appear as OBSERVED_ONLY candidates.
WITH expected AS (
  SELECT object_owner, object_name, object_type,
         COUNT(*) AS policy_rows
    FROM tetools.admin_objects_ledger
   WHERE module = :p_module
   GROUP BY object_owner, object_name, object_type
), observed AS (
  SELECT USER AS object_owner, object_name, object_type,
         created, last_ddl_time, status AS dictionary_status
    FROM user_objects
   WHERE subobject_name IS NULL
     AND generated = 'N'
), reconciled AS (
  SELECT COALESCE(e.object_owner,o.object_owner) AS object_owner,
         COALESCE(e.object_name,o.object_name) AS object_name,
         COALESCE(e.object_type,o.object_type) AS object_type,
         e.policy_rows, o.created, o.last_ddl_time, o.dictionary_status,
         CASE
           WHEN e.policy_rows > 1 THEN 'AMBIGUOUS_POLICY'
           WHEN e.object_name IS NULL THEN 'OBSERVED_ONLY'
           WHEN o.object_name IS NULL THEN 'EXPECTED_ONLY'
           ELSE 'BOTH'
         END AS reconciliation_state
    FROM expected e
    FULL OUTER JOIN observed o
      ON e.object_owner = o.object_owner
     AND e.object_name = o.object_name
     AND e.object_type = o.object_type
)
SELECT * FROM reconciled
 ORDER BY reconciliation_state, object_owner, object_name, object_type;
-- OBSERVED_ONLY means unassigned to the selected manifest/ledger subset.
-- It does not prove ownership by that module. No prefix inference is applied.
-- A full implementation needs edition policy, generated children, job adapters,
-- scan completeness, module relations, lifecycle history, and persisted usage.
