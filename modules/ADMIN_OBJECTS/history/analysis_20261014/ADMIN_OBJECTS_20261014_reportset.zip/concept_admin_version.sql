-- CONCEPT C01: independent ADMIN_VERSION candidate, Oracle 19c.
-- Not compiled or executed. Not a replacement ADMIN_OBJECTS package.
-- Proposed contract: 1-8 segments, each 1-9 digits; absent segments = 0.
-- Existing OLDER/EQUAL/NEWER wrappers can map -1/0/1 after caller review.
CREATE OR REPLACE PACKAGE tetools.admin_version AUTHID DEFINER AS
  FUNCTION compare_versions(p_left IN VARCHAR2, p_right IN VARCHAR2)
    RETURN PLS_INTEGER;
  FUNCTION range_status(p_current IN VARCHAR2,
                        p_minimum IN VARCHAR2,
                        p_maximum IN VARCHAR2) RETURN VARCHAR2;
END admin_version;
/
CREATE OR REPLACE PACKAGE BODY tetools.admin_version AS
  TYPE version_parts_t IS TABLE OF NUMBER INDEX BY PLS_INTEGER;

  PROCEDURE parse_version(p_text IN VARCHAR2,
                          p_parts OUT version_parts_t,
                          p_count OUT PLS_INTEGER) IS
    l_segment VARCHAR2(9);
  BEGIN
    -- Validate the complete input before converting any segment.
    -- A whole-number segment has no decimal or grouping separator.
    IF p_text IS NULL OR LENGTH(p_text) > 128 OR
       NOT REGEXP_LIKE(p_text,
         '^[0-9]{1,9}(\.[0-9]{1,9}){0,7}$', 'c') THEN
      RAISE_APPLICATION_ERROR(-20101, 'Invalid dotted version');
    END IF;
    p_parts.DELETE;
    p_count := REGEXP_COUNT(p_text, '\.') + 1;
    FOR i IN 1 .. p_count LOOP
      l_segment := REGEXP_SUBSTR(p_text, '[0-9]+', 1, i);
      p_parts(i) := TO_NUMBER(l_segment);
    END LOOP;
  END parse_version;

  FUNCTION compare_parts(p_left IN version_parts_t,
                          p_left_count IN PLS_INTEGER,
                          p_right IN version_parts_t,
                          p_right_count IN PLS_INTEGER)
    RETURN PLS_INTEGER IS
    l_left NUMBER;
    l_right NUMBER;
  BEGIN
    -- Compare both complete tuples; pad absent trailing parts with zero.
    FOR i IN 1 .. GREATEST(p_left_count, p_right_count) LOOP
      l_left := 0;
      l_right := 0;
      IF p_left.EXISTS(i) THEN l_left := p_left(i); END IF;
      IF p_right.EXISTS(i) THEN l_right := p_right(i); END IF;
      IF l_left < l_right THEN RETURN -1; END IF;
      IF l_left > l_right THEN RETURN 1; END IF;
    END LOOP;
    RETURN 0;
  END compare_parts;

  FUNCTION compare_versions(p_left IN VARCHAR2, p_right IN VARCHAR2)
    RETURN PLS_INTEGER IS
    l_left version_parts_t;
    l_right version_parts_t;
    l_left_count PLS_INTEGER;
    l_right_count PLS_INTEGER;
  BEGIN
    parse_version(p_left, l_left, l_left_count);
    parse_version(p_right, l_right, l_right_count);
    RETURN compare_parts(l_left, l_left_count, l_right, l_right_count);
  END compare_versions;

  FUNCTION range_status(p_current IN VARCHAR2,
                        p_minimum IN VARCHAR2,
                        p_maximum IN VARCHAR2) RETURN VARCHAR2 IS
    l_current version_parts_t;
    l_minimum version_parts_t;
    l_maximum version_parts_t;
    l_current_count PLS_INTEGER;
    l_minimum_count PLS_INTEGER;
    l_maximum_count PLS_INTEGER;
  BEGIN
    -- Parse each input once. No SQL, logging, configuration, or session DML.
    parse_version(p_current, l_current, l_current_count);
    parse_version(p_minimum, l_minimum, l_minimum_count);
    parse_version(p_maximum, l_maximum, l_maximum_count);
    IF compare_parts(l_minimum, l_minimum_count,
                     l_maximum, l_maximum_count) > 0 THEN
      RAISE_APPLICATION_ERROR(-20102, 'Reversed version interval');
    END IF;
    IF compare_parts(l_current, l_current_count,
                     l_minimum, l_minimum_count) < 0 THEN
      RETURN 'FUTURE RELEASE';
    END IF;
    IF compare_parts(l_current, l_current_count,
                     l_maximum, l_maximum_count) > 0 THEN
      RETURN 'INACTIVE';
    END IF;
    RETURN 'ACTIVE';
  END range_status;
END admin_version;
/
